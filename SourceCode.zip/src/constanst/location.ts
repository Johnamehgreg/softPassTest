export interface LocationParams {
    pathname: string;
    state: any;
    search: string;
    hash: string;
    key: string;
  }