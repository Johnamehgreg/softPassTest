

const DashboardChat = () => {
    return (
        <div className="dashboard-chat-container px-4 py-5">
            <div className="flex mb-4 justify-between items-center">
                <p className="">
                Overview
                </p>

                <div className="left-chat-d-cont">
                    <button>
                    Select verification ID
                    Select verification ID
                    Select verification ID
                    Select verification ID
                    Select verification ID
                    Select verification ID
                    Select verification ID
                    Select verification ID

                    {/* <IoMdArrowDropdown color='black' size={10}/> */}
                    </button>
                </div>
            </div>

            <hr />
        </div>
    )
}

export default DashboardChat
