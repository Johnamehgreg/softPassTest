

const routes = {
    dashboard: '/dashboard',
    verification:[
        {
            pages: 'identity-verification',
        }
    ]
}


export default routes