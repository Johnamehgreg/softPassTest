import moment from "moment";
import { useEffect, useState } from "react";
import { AiOutlinePlus } from "react-icons/ai";
import edit from '../../../../../assets/svg/edit.svg';
import AppDeleteModal from "../../../../../components/AppComponent/AppDeleteModal";
import CopyIcon from "../../../../../components/svg-icons/CopyIcon";
import AddContainerServices from "../modals/AddServices";
import { useGetServiceByContainer, useServicesEvent } from "../modals/container-query-hook";
import DeactivateContainers from "../modals/DeactivateContainerModal";
import EditContainers from "../modals/EditContainerModal";

import CardContainer from "./card";


interface Props {
    item: any;
    refetch: Function
}

const ContainerItem: React.FC<Props> = ({ item, refetch }) => {
    let date = moment(item?.createdAt).format('d/m/yyyy')

    const [servicesList, setservicesList] = useState([])

    const [isColase, setisColase] = useState(true)

    const [isEditContOpen, setIsEditContOpen] = useState(false)
    const [isDeactivateContOpen, setIsDeactivateContOpen] = useState(false)
    const [isDeleteServiceOpen, setisDeleteServiceOpen] = useState(false)
    const [isAddServiceOpen, setisAddServiceOpen] = useState(false)
    const [serviceIndex, setserviceIndex] = useState(0)
    const closeDeactivateContainerModal = (val: boolean) => {
        setIsDeactivateContOpen(val)
    }

    const closeEditContainerModal = (val: boolean) => {
        setIsEditContOpen(val)
    }

    const onError = () => {

    }

    const { isSuccess, refetch: serviceRefetch, isFetched, data } = useGetServiceByContainer({ onError, containerId: item._id })

    const { deleteService } = useServicesEvent({ refetch: serviceRefetch, closeModal: () => setisDeleteServiceOpen(false) })

    const checkSuccess = () => {

        if (isFetched && isSuccess) {
            setservicesList(data?.data)


        }
    }

    const handleServicesDelete = () => {
        let serviceId: any = servicesList[serviceIndex]

        deleteService({ servicesId: serviceId.service_id.id, containerId: item._id })



    }


    useEffect(() => {
        checkSuccess()
    }, [data])


    return (
        <>
            <CardContainer>
                <>
                    <div key={item?._id} className="flex justify-between w-full py-3">
                        <h2>
                            {item?.container_name}
                        </h2>

                        {
                            isColase && (

                                <div className="text-gray-400 hidden md:flex flex-col justify-center items-center">
                                    <p className="text-[13px]">Container key</p>
                                    <p className=" text-[14px]">
                                        {item?.container_key}&nbsp;{" "}
                                    </p>
                                </div>
                            )

                        }






                        <div className=" flex items-center justify-center ">

                            {
                                isColase && (
                                    <button
                                        className="w-10 mx-2">
                                        <CopyIcon width={"18"} color={"black"} />
                                    </button>
                                )
                            }
                            <span
                                onClick={() => setIsEditContOpen(true)}
                            >
                                <img className="pointer" src={edit} />
                            </span>



                            {
                                isColase ?
                                    <button
                                        onClick={() => setisColase(false)}
                                        className="w-6 ml-8 h-7 flex justify-center items-center rounded-md bg-gray-200">
                                        <AiOutlinePlus fill="black" />
                                    </button>
                                    :

                                    <div
                                        onClick={() => setisColase(true)}
                                        className="ml-8 cont-page-remove pointer">
                                        <div className="inner"></div>
                                    </div>

                            }


                        </div>
                    </div>

                    {
                        !isColase && (
                            <div className="flex w-full items-center flex-wrap mt-8">
                                {servicesList.map((item: any, index) => {
                                    return (
                                        <div className="item-key my-2">
                                            <p>{item.service_id.service_name} &nbsp; <abbr
                                                onClick={() => {
                                                    setisDeleteServiceOpen(true)
                                                    setserviceIndex(index)
                                                }}
                                                className="text-black pointer text-[15px]">&times;</abbr></p>
                                        </div>
                                    );
                                })}
                                <div onClick={() => setisAddServiceOpen(true)} className="item-key w-9 pointer h-7">
                                    <AiOutlinePlus />
                                </div>
                            </div>
                        )
                    }

                    {
                        !isColase && (

                            <div className="flex w-full ">
                                <div className="pt-5 text-gray-400 leading-3 w-full">
                                    <p className="text-[13px]">Container key</p>
                                    <div className="flex items-center flex-wrap text-[13px] w-full pb-3">
                                        <div className="sm:w-6/12 w-full flex items-center">
                                            {item?.container_key}&nbsp;{" "}
                                            <CopyIcon width={"18"} color={"black"} />
                                        </div>

                                        <div className="sm:w-6/12 w-full flex flex-wrap items-center">
                                            {
                                                item?.is_active === true ?

                                                    <span
                                                        onClick={() => setIsDeactivateContOpen(true)}
                                                        className="text-softpasspurple-300 font-semibold pointer mr-4">
                                                        Deactivate container
                                                    </span>

                                                    :

                                                    <span
                                                        onClick={() => setIsDeactivateContOpen(true)}
                                                        className="text-softpasspurple-300 font-semibold pointer mr-4">
                                                        Activate container
                                                    </span>
                                            }
                                            <span>{date}</span>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        )
                    }
                </>
            </CardContainer>
            <EditContainers item={item} refetch={refetch} isOpen={isEditContOpen} closeModal={closeEditContainerModal} />
            <DeactivateContainers refetch={refetch} item={item} isOpen={isDeactivateContOpen} closeModal={closeDeactivateContainerModal} />
            <AppDeleteModal onDelete={() => handleServicesDelete()} item={servicesList[serviceIndex]} isOpen={isDeleteServiceOpen} closeModal={() => setisDeleteServiceOpen(false)} />
            <AddContainerServices item={item} refetch={serviceRefetch} isOpen={isAddServiceOpen} closeModal={() => setisAddServiceOpen(false)} />


        </>

    )
}



export default ContainerItem