import React from 'react'

interface Props {}

function AccountAuth(props: Props) {
    const {} = props

    return (
       <div></div>
    )
}

export default AccountAuth
