
const Test = () => {
    return (
        <div className="flex flex-wrap">
            <p className="text-[2px] md:text-[50px] sm:text-[10px]">Happy world and me</p>
            
        </div>
    )
}

export default Test
