export enum AppType {
    APP = 'app',
    LANDING = 'landing',
    AUTH = 'auth'
} 