import { createContext } from "react"

export const AppProvider = createContext<any >(null)


