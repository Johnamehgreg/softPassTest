import { createContext } from "react"

export const AuthProvider = createContext<any >(null)


