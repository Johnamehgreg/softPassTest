import React from 'react'

interface Props {
    width: string | number,
}

function HouseBoxIcon(props: Props) {
    const { width } = props

    return (
        <svg width={width} height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="6" fill="#E12179"/>
        <path d="M14.63 17.7498C14.28 17.8898 14 18.3098 14 18.6798V21.9998C14 22.5498 14.45 22.9998 15 22.9998H33C33.55 22.9998 34 22.5498 34 21.9998V18.6798C34 18.3098 33.72 17.8898 33.37 17.7498L24.37 14.1498C24.17 14.0698 23.83 14.0698 23.63 14.1498L18.79 16.0898" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M34 34H14V31C14 30.45 14.45 30 15 30H33C33.55 30 34 30.45 34 31V34Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M16 30V23" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M20 30V23" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M24 30V23" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M28 30V23" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M32 30V23" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M13 34H35" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M24 20.5C24.8284 20.5 25.5 19.8284 25.5 19C25.5 18.1716 24.8284 17.5 24 17.5C23.1716 17.5 22.5 18.1716 22.5 19C22.5 19.8284 23.1716 20.5 24 20.5Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    )
}

export default HouseBoxIcon
