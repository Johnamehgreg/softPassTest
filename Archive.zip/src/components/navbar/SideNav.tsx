import React from 'react'

interface Props {}

function SideNav(props: Props) {
  const {} = props

  return (
    <div>
      
    </div>
  )
}

export default SideNav
