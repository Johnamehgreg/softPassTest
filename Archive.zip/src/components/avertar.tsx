import React from 'react'

const Avertar = () => {
  return (
    <div className='averter'>
        <img src="https://i.pinimg.com/originals/fc/ee/3e/fcee3e7d92dad2cb59802c0bb1e667fb.jpg" alt="" />
    </div>
  )
}

export default Avertar