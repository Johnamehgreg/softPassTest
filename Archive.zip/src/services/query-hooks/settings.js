export const setParams = {
    BASE_URL : "https://6270020422c706a0ae70b72c.mockapi.io/lendsqr/api/v1",
    responseType : 'json',
    // set time for axios request
    // set 0 to cancle timeout
    timeout : 5000,
    token : 'token',
    setToken : 'Authorization',
}