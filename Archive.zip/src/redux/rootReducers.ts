import  navToggleSlice from "./navigation/navToggle"



const rootReducer = {
    toggle: navToggleSlice
}


export default rootReducer