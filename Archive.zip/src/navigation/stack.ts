import { AppType } from "../constanst/ApptypeEnum"


const route = {
    APP: AppType.APP,
    AUTH: AppType.AUTH,
    Landing: AppType.LANDING,
}


export default route